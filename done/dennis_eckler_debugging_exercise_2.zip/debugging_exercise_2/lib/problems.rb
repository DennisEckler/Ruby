# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

require "byebug"

def prime?(num)
    (2...num).each { |factor| return false if num % factor == 0}
    return true
end

def largest_prime_factor(num)
    primes = (1..num).select { |n| prime?(n) && num % n == 0}
    return primes.max
end

def unique_chars?(str)
    hash = Hash.new(0)
    str.each_char { |c| hash[c] += 1}
    hash.each_value { |v| return false if v > 1}
    return true
end

def dupe_indices(arr)
    dupe_hash = Hash.new(0)
    indicies_hash = Hash.new { |h, k| h[k] = [] }
    arr.each { |ele| dupe_hash[ele] += 1}
    arr.each.with_index do |ele, i|
        if dupe_hash[ele] > 1
            indicies_hash[ele] << i
        end
    end
    return indicies_hash
end

def create_hash(arr)
    hash = Hash.new(0)
    arr.each { |word| hash[word] += 1 }
    return hash
end 


def ana_array(arr_1, arr_2)
    hash_1 = create_hash(arr_1)
    hash_2 = create_hash(arr_2)
    return true if hash_1 == hash_2
    return false
end