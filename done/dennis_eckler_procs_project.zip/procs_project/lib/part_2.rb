def reverser(string, &proc)
    proc.call(string.reverse)
end

def word_changer(string, &proc)
    new_str = ""
    string.split(" ").each { |word| new_str += proc.call(word) + " "}
    return new_str[0..-2]
end

def greater_proc_value(num, proc_1, proc_2)
    return proc_1.call(num) if proc_1.call(num) > proc_2.call(num)
    return proc_2.call(num)

end

def and_selector(array, proc_1, proc_2)
    new_arr = []
    array.each { |ele| new_arr << ele if proc_1.call(ele) && proc_2.call(ele)}
    new_arr
end

def alternating_mapper(array, proc_1, proc_2)
    new_array = []
    array.each.with_index do |num, idx|
        if idx.even?
            new_array << proc_1.call(num)
        else
            new_array << proc_2.call(num)
        end
    end
    new_array
end