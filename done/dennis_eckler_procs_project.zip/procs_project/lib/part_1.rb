require "byebug"

def my_map(array, &proc)
    new_array = []
    array.each do |ele|
        new_array << proc.call(ele)
    end
    new_array
end

def my_select(array, &proc)
    new_array = []
    array.each do |ele|
        if proc.call(ele)
            new_array << ele
        end
    end
    new_array
end

def my_count(array, &proc)
    count = 0
    array.each do |ele|
        if proc.call(ele)
            count += 1
        end
    end
    count
end

def my_any?(array, &proc)
    array.each do |ele|
        if proc.call(ele)
            return true
        end
    end
    return false
end

def my_all?(array, &proc)
    array.each { |ele| return false if !(proc.call(ele))}
    return true
end

def my_none?(array, &proc)
    array.each { |ele| return false if proc.call(ele)}
    return true
end