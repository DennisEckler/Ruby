class Player

    def get_move
        puts "enter a position with coordinates separated wit a space like 4 7"
        user_input = gets.chomp
        return user_input.split(" ").map &:to_i
    end

end
