class Board

    attr_reader :size

    def self.print_grid(grid)
        grid.each { |row| puts row.join(" ")}
    end


    def initialize(n)
        @grid = Array.new(n) {Array.new(n, :N)}
        @size = n * n
    end


    def [](row_column_pair)
        @grid[row_column_pair[0]][row_column_pair[1]]
    end

    def []=(position, value)
        @grid[position[0]][position[1]] = value
    end

    def num_ships
        @grid.flatten.count(:S)
    end

    def attack(position)
        if self[position]  == :S
            self[position] = :H 
            puts "you sunk my battleship!"
            return true
        else
            self[position] = :X
            return false
        end
    end


    def place_random_ships
        while self.num_ships < (@size * 0.25)
            rand1 = rand(0...@grid.length)
            rand2 = rand(0...@grid.length)
            pos = [rand1, rand2]
            self[pos] = :S
        end
    end

    def hidden_ships_grid
        @grid.map do |row|
            row.map do |ele|
                if ele == :S
                    :N
                else
                    ele
                end
            end
        end
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(self.hidden_ships_grid)
    end

end
