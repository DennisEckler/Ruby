require "byebug"

def all_words_capitalized?(arr)
    arr.all? { |ele| ele == ele.capitalize}
end

def no_valid_url?(arr)
    endings = [".com", ".net", ".io", ".org"]
    arr.none? { |ele| endings.include?(ele[ele.index(".")..-1]) }
end

def any_passing_students?(arr)
    arr.any? do |hash| 
        (hash[:grades].sum / hash[:grades].length) >= 75
    end
end