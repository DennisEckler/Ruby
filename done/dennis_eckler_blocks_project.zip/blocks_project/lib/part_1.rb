def select_even_nums(arr)
    arr.select(&:even?)
end

def reject_puppies(arr)
    arr.reject { |dog| dog["age"] <= 2 }
end

def count_positive_subarrays(arr)
    arr.count { |array| array.sum > 0}
end

def aba_translate(word)
    vowels = "aeiou"
    new_word = ""
    word.each_char do |c|
        new_word += c
        if vowels.include?(c)
            new_word += "b" + c
        end
    end
    return new_word
end

def aba_array(array)
    abaedarr = array.map { |ele| aba_translate(ele) }
    return abaedarr
end
