def partition(arr, num)
    combined = []
    greater = arr.select { |ele| ele >= num }
    lower = arr.select { |ele| ele < num }
    combined << lower
    return combined << greater
end

def merge(hash_1, hash_2)
    hash = {}
    hash_1.each_key { |key| hash[key] = hash_1[key]}
    hash_2.each_key { |key| hash[key] = hash_2[key]}
    return hash
end


def censor(str, arr)
    vowels = "aeiouAEIOU"
    cursed = str.split(" ")
    cursed.each.with_index do |word, idx|
        if arr.include?(word.downcase) 
            word.each_char.with_index do |char, i|
                if vowels.include?(char)
                    word[i] = "*"
                end
                cursed[idx] = word
            end
        end
    end
    return cursed.join(" ")
end

def power_of_two?(num)
    powers = [1]
    while powers[-1] < num
        powers << powers[-1] * 2
    end
    return true if powers.include?(num)
    return false
end