def palindrome?(str)
    palistr = ""
    str.each_char do |char|
        palistr = char + palistr
    end
    return true if str == palistr
    return false
end

def substrings(str)
    arr = []
    beg = 0
    en = 0
    while beg < str.length
        while en < str.length
            arr << str[beg..en]
            en += 1
        end
        beg += 1
        en = beg
    end
    return arr
end

def palindrome_substrings(str)
    palindromes = []
    arrays = substrings(str)
    palindromes = arrays.select { |ele| ele.length > 1 && palindrome?(ele) }
    return palindromes
end
