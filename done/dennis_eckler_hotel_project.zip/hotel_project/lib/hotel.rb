require_relative "room"

class Hotel

    def initialize(name, hashroom)
        @name = name
        @rooms = {}
        hashroom.each do |k, v| 
            room = Room.new(v)
            @rooms[k] = room
        end
    end

    def name
        @name.split(" ").map(&:capitalize).join(" ")
    end
    def rooms
        @rooms
    end
    def room_exists?(roomname)
        self.rooms.has_key?(roomname)
    end

    def check_in(entered_guest, entered_room)
        if self.room_exists?(entered_room)
            if @rooms[entered_room].add_occupant(entered_guest)
                puts "check in successful"
            else
                puts "sorry room is full"
            end
        else
            puts "sorry room does not exist"
        end
    end

    def has_vacancy?
        @rooms.values.any? { |room| room.available_space > 0 }
    end
    
    def list_rooms
        @rooms.each do |room_name, room|
            puts "#{room_name} : #{room.available_space}"
        end
    end
end
