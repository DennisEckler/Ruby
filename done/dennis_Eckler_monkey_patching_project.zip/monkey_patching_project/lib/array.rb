# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
  #PART1
  def span
    if self.empty?
      return nil
    end
    self.max - self.min
  end
  def average
    if self.empty?
      return nil
    end
    return (self.sum * 1.0) / self.length
  end
  def median
    if self.empty?
      return nil
    end
    if self.length.even?
      for_average = []
      for_average << self.sort[self.length / 2]
      for_average << self.sort[(self.length / 2) - 1]
      return for_average.average
    else
      self.sort[self.length / 2]
    end
  end
  def counts
    hashcount = Hash.new(0)
    self.each { |ele| hashcount[ele] += 1}
    return hashcount
  end
  #PART2
  def my_count(ele)
    count = 0
    self.each { |sub_arr| count += 1 if sub_arr == ele}
    return count 
  end

  def my_index(val)
    return nil if !self.include?(val)
    self.each.with_index do |ele, idx|
      return idx if val == ele
    end
  end

  def my_uniq
    new_array = []
    self.each { |ele| new_array << ele if !new_array.include?(ele)}
    return new_array
  end

  def my_transpose
    transposed = []
    looparr = []
    count = 0
    self.length.times do
      self.each do |sub_arr|
        looparr << sub_arr[count]
      end
      transposed << looparr
      looparr = []
      count += 1
    end
    return transposed
  end 

  #def alvins_transpose
  #  new_arr = []
  #  (0...self.length).each do |row|
  #    new_row= []
  #    (0...self.length).each do |col|
  #      new_row << self[col][row]
  #    end
  #    new_arr << new_row
  #  end
  #  new_arr
  #end
end
